package com.UST.springbootDocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
